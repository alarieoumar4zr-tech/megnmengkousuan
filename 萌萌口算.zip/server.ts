import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Lazily initialize GoogleGenAI SDK to prevent server startup crash if key is missing
let aiInstance: GoogleGenAI | null = null;
function getAndVerifyAI(): GoogleGenAI {
  if (!aiInstance) {
    const geminiApiKey = process.env.GEMINI_API_KEY;
    if (!geminiApiKey) {
      throw new Error('GEMINI_API_KEY environment variable is required for AI Tutor explanations');
    }
    aiInstance = new GoogleGenAI({
      apiKey: geminiApiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiInstance;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for JSON requests
  app.use(express.json());

  // AI Tutor Q&A Explanations Route
  app.post('/api/explain', async (req, res) => {
    try {
      const { num1, num2, operator, correctAnswer } = req.body;

      if (num1 === undefined || num2 === undefined || !operator) {
        return res.status(400).json({ error: '缺少题目信息参数呀' });
      }

      const prompt = `请帮我讲解口算题：${num1} ${operator} ${num2} = ${correctAnswer}。`;

      const aiInstance = getAndVerifyAI();
      const response = await aiInstance.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          systemInstruction: '你是一位超级温柔、耐心的儿童趣味数学启萌老师“暖暖熊”。请用非常逗趣、可爱、通俗易懂的具象化语言（比如通过分棒棒糖、数草莓、借苹果，或者十位数大变身拆分算法），给一个8岁的小朋友生动讲解这道口算题目是怎么算出来的。绝对不要用任何复杂的公式、大学名词，150字以内，每句话都要充满温暖和鼓励（例如常说：宝贝、小探险家、加油、真棒！），段落要简短清晰，多用一些可爱的 emoji。若减法需要借位，请巧妙说明。',
          temperature: 0.8,
        },
      });

      const explanation = response.text || '哎呀，魔法小熊老师打了个盹，没有准备好这道题的魔法解答。宝贝再试一次哦！';

      return res.json({ explanation });
    } catch (err: any) {
      console.error('Gemini API Error:', err);
      // Give a friendly fallback so the user experience doesn't break
      return res.json({ 
        explanation: '💖 暖暖熊老师由于魔法能量暂时不足（API Key未配置或访问繁忙），给你一个超级元气拥抱！算术原理：我们可以把数拆分成好算的部分（比如把大数先凑满十，或者把被减数拆开），加油！你一定能跨越这个知识小山丘的！🌈✨' 
      });
    }
  });

  // Vite static/middleware server mounting
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
